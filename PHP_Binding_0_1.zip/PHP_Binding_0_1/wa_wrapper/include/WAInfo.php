<?php

/** 
 *  The Wolfram Alpha Info Object
 *  @package WolframAlpha
 */
class WAInfo {
  // define the sections of a response
  public $text = '';
 
  // Constructor
  public function WAInfo () {
  }

}
?>

