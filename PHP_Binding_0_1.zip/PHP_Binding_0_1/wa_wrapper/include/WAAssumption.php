<?php

/** 
 *  The Wolfram Alpha Assumption Object
 *  @package WolframAlpha
 */
class WAAssumption {
  // define the sections of a response
  public $type = '';
  public $word = '';
  public $name = '';
  public $description = '';
  public $input = '';
 
  // Constructor
  public function WAAssumption () {
  }

}
?>

